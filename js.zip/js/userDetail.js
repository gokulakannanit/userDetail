$(document).ready(function () {
  $.get('/user/get/all', '', function (data) {
    if (data.length < 1) {
      $('#userDetail tbody').append('<tr><td>No Records Found</td></tr>');
    }
    data.forEach((user) => {
      $('#userDetail tbody').append(
        '<tr><td>' +
          user.name +
          '</td><td>' +
          user.email +
          "</td><td><a href='void:javascript(0)' onclick='getDetail(" +
          user.id +
          ")'></td></tr>"
      );
    });
  });
});

const getDetail = (id) => {
  $.get('/user/get/' + id, '', function (data) {
    //TODO
    if (data.length < 1) {
      $('#userInfo tbody').append('<tr><td>No Records Found</td></tr>');
    }
    data.forEach((user) => {
      $('#userInfo tbody').append(
        '<tr><td>' + user.name + '</td><td>' + user.email + '</td></tr>'
      );
    });
  });
};
