$(document).ready(function () {
  $('#login').click(function () {
    var email = $('#email').val();
    var password = $('#password').val();
    if (email == '' || password == '') {
      alert('Please fill all fields...!!!!!!');
    } else {
      $.get(
        '/user/login',
        {
          email: email,
          password: password,
        },
        function (data) {
          if (data) {
            window.location.href = '/userDetail.html';
          }
          alert(data);
        }
      );
    }
  });
});
