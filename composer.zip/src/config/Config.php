<?php
namespace user;
class Config
{
    
    public function __construct()
    {
    }
    
}