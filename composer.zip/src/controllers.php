<?php
namespace user;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/*
 * Adds all the controllers to $app.  Follows Silex Skeleton pattern.
 */

$prefix = '/user/public';

$defaultRoutes = array('user');

function getParsedBody()
{
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) $data = $_POST;
    return $data;
}

function initiateDefaultRoute($app, $name, $prefix = '')
{
    $urlPrefix = $prefix . '/' . $name;
    $app->post($urlPrefix . '/create', function () use ($name) {
        return $this->get($name)->create(getParsedBody());
    });

    $app->post($urlPrefix . '/update', function () use ($name) {
        return $this->get($name)->update(getParsedBody());
    });

    $app->get($urlPrefix . '/get/all', function () use ($name) {
        return $this->get($name)->getAll();
    });

    $app->get($urlPrefix . '/get/{id}', function ($request, $response, $args) use ($name) {
        return $this->get($name)->getById($args['id']);
    });

    $app->post($urlPrefix . '/delete/{id}', function ($request, $response, $args) use ($name) {
        return $this->get($name)->deleteById($args['id']);
    });

    $app->post($urlPrefix . '/drop', function () use ($name) {
        return $this->get($name)->drop();
    });

    $app->get($urlPrefix . '/get/others/{column}/{id}', function ($request, $response, $args) use ($name) {
        $column = $args['column'];
        $id = $args['id'];
        return $this->get($name)->getByOtherForeignId("$column=$id");
    });
}

foreach ($defaultRoutes as &$value) {
    initiateDefaultRoute($app, $value, $prefix);
}

$app->post($prefix . '/user/login', function () {
    return $this->get('user')->verifyUser(getParsedBody());
});

$app->get($prefix . '*', function (Request $req, Response $res) {
    return $res
        /* ->withHeader('Content-Type', 'application/json') */
        ->withStatus(404);
});