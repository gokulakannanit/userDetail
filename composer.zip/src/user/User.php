<?php
namespace user;
class User extends Base
{
    protected $tableName = 'user';
    protected $columns = array(
        'id SERIAL PRIMARY KEY',
        'email VARCHAR(255) NOT NULL',
        'firstname VARCHAR(255) NOT NULL',
        'lastname VARCHAR(255) NOT NULL',
        'password VARCHAR(255) NOT NULL',
        'createdAt timestamp NOT NULL DEFAULT current_timestamp()',
    );
    public function __construct($container)
    {
        parent::__construct($container);
    }

    /**
     * private
     * 
     * verify login
     **/
    public function verifyUser($data)
    {
        $cond = "email=" . $data['email'];
        $isExist = $this->db->isExist($this->tableName, $cond." AND password=". $data['password']);
        $response = true;
        if (!$isExist) {
            $response = false;
            return $this->rh->loginFail();
        }
        return $this->rh->success($response);
    }
    
}