<?php

namespace farmfreshi\meat\util;

class Util
{

  public function __construct()
  {
  }

  public static function getResponseBody($response)
  {
  }

  public static function fetchDate($dateinterval)
  {
    return  date('Y-m-d', strtotime(date("Y-m-d") . ' +' . $dateinterval . 'days'));
  }

  public static function log_debug($msg)
  {
    //print '::MSG START::' . var_dump($msg) . '::MSG END::';
  }
}