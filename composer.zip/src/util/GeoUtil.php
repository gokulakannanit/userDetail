<?php

namespace farmfreshi\meat\util;

class GeoUtil
{
    public static $API_KEY = '';

    public static $GEO_URI = "https://maps.googleapis.com/maps/api/geocode/json?latlng=";

    public function __construct()
    {
    }

    public static function findNearestStore($stores, $destination)
    {
        $distances = array_map(function ($item) use ($destination) {
            return GeoUtil::distance($item, $destination);
        }, $stores);

        $nearestStore = null;
        array_map(function ($item) use (&$nearestStore) {
            if (!$nearestStore || (int)$nearestStore['km'] > (int) $item['km']) {
                $nearestStore = $item;
            }
        }, $distances);
        return $nearestStore;
    }


    public static function splitLatnLng($address)
    {
        $latandlng = explode(',', $address['latandlng']);
        $address['lat'] =  floatval($latandlng[0]);
        $address['lng'] =  floatval($latandlng[1]);
        return $address;
    }

    public static function distance($addressFrom, $addressTo)
    {
        $unit = 'K';
        $src = GeoUtil::splitLatnLng($addressFrom);
        $dest = GeoUtil::splitLatnLng($addressTo);

        $latitudeFrom = $src['lat'];
        $longitudeFrom = $src['lng'];
        $latitudeTo = $dest['lat'];
        $longitudeTo = $dest['lng'];

        // Calculate distance between latitude and longitude
        $theta    = $longitudeFrom - $longitudeTo;
        $dist    = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) +  cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
        $dist    = acos($dist);
        $dist    = rad2deg($dist);
        $miles    = $dist * 60 * 1.1515;

        if ($unit == "K") {
            $distant =  round($miles * 1.609344, 2);
        } elseif ($unit == "M") {
            $distant = round($miles * 1609.344, 2);
        } else {
            $distant =  round($miles, 2);
        }
        $addressFrom['km'] = (int)$distant;

        return $addressFrom;
    }

    public static function getGeoContent($latlng)
    {
        $geocode = file_get_contents(GeoUtil::$GEO_URI . $latlng . '&sensor=false&key=' . GeoUtil::$API_KEY);
        return json_decode($geocode);
    }
}