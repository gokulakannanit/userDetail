<?php

use CloudSqlDataModel;

use Psr\Container\ContainerInterface;
use Slim\Factory\AppFactory;
use DI\Container;

$nameSpace = 'user';

$generic = ['Session', 'ResponseHandler'];
$users = ['User'];
$util = ['Util'];

$container = new Container();
AppFactory::setContainer($container);

$app = AppFactory::create();

$app->addRoutingMiddleware();
$errorMiddleware = $app->addErrorMiddleware(true, true, true);

function initiate($container, $classes, $nameSpace)
{
    foreach ($classes as &$value) {
        $key = lcfirst("$value");
        $classObj = $nameSpace . '\\' . $value;
        $container->set($key, function (ContainerInterface $c) use ($classObj) {
            return new $classObj($c);
        });
    }
}

initiate($container, $generic, $nameSpace);
initiate($container, $users, $nameSpace . '\user');
initiate($container, $util, $nameSpace . '\util');

$container->set('cloudsql', function () {
    // Data Model
    $dbName = 'user';
    $dbConn = '';
    $dbUser = 'root';
    $dbPass = '';
    $hostName = null;
    $hostName = 'localhost';
    $port = 3306;

    if ($hostName) {
        $dsn = sprintf('mysql:dbname=%s;host=%s;port=%s', $dbName, $hostName, $port);
    } else {
        // Connect using UNIX sockets
        $dsn = sprintf(
            'mysql:dbname=%s;unix_socket=/cloudsql/%s',
            $dbName,
            $dbConn
        );
    }


    $pdo = new PDO($dsn, $dbUser, $dbPass);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return new CloudSqlDataModel($pdo);
});

return $app;