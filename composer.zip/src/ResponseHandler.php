<?php

namespace user;

use GuzzleHttp\Psr7\Response;

class ResponseHandler
{
    private $status = [
        'OK' => 200,
        'NOT_OK' => 500,
        'UN_AUTHORIZED' => 401,
    ];
    public $response;
    public function __construct()
    {
    }

    public function success($payload)
    {
        $this->response = new Response();
        $body = $this->response->getBody();
        $body->write(json_encode($payload, true));
        return $this->response
            ->withStatus($this->status['OK']);
    }

    public function loginFail()
    {
        $this->response = new Response();
        $body = $this->response->getBody();
        $body->write('USER NOT AUTHORIZED');
        return $this->response
            ->withStatus($this->status['UN_AUTHORIZED']);
    }

    public function error($msg = 'Something went wrong')
    {
        $this->response = new Response();
        $body = $this->response->getBody();
        $body->write($msg);
        return $this->response
            /* ->withHeader('Access-Control-Allow-Origin', '*') */
            ->withStatus($this->status['NOT_OK']);
    }
}