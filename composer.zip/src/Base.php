<?php
namespace user;
class Base
{
    protected $db;
    protected $rh;
    protected $sh;
    protected $ul;
    protected $tableName = '';
    protected $container;
    public function __construct($container = null)
    {
        $this->db = $container->get('cloudsql');
        $this->rh = $container->get('responseHandler');
        $this->sh = $container->get('session');
        $this->ul = $container->get('util');
        $this->container = $container;
        $this->db->createTable($this->tableName, $this->tableData());
    }

    public function drop()
    {
        $result = $this->db->dropTable($this->tableName);
        if ($result) {
            return $this->rh->success($result);
        }
        return $this->rh->error("Error occured while dropping the table $this->tableName");
    }

    /**
     * Create Type
     * 
     * @param data array 
     * 
     */
    public function create($data)
    {
        $data = $this->filterOnlyAvaiableColumns($data);
        $result = $this->db->insert($this->tableName, $data);
        if ($result) {
            return $this->rh->success($result);
        }
        return $this->rh->error("Record not inserted in $this->tableName");
    }

    /**
     * Insert row in database
     * 
     * @param data array 
     * 
     */
    public function update($data, $condition = null)
    {
        $data = $this->filterOnlyAvaiableColumns($data);
        $result = $this->db->update($this->tableName, $data, $condition);
        if ($result) {
            return $this->rh->success($result);
        }
        return $this->rh->error("Record not updated in $this->tableName");
    }

    public function filterOnlyAvaiableColumns($data)
    {
        $result = [];
        $columns = $this->columnNames;
        foreach ($columns as $key) {
            if (isset($data[$key])) {
                $value = $data[$key];
                $result[$key] = addslashes($value);
            }
        }
        return $result;
    }

    protected function getForeignValues($value)
    {
        return $value;
    }


    /**
     * Return Product Data
     * 
     */
    public function getAll()
    {
        $result = $this->db->getAll($this->tableName);
        if (is_array($result)) {
            return $this->rh->success($this->feedForeignValue($result));
        }
        return $this->rh->error("Error fetching getting record $this->tableName");
    }

    /**
     * Return Record for given id
     * 
     * @param id string
     */
    public function getById($id)
    {
        $result = $this->db->getAll($this->tableName, "id=$id");
        if (is_array($result)) {

            if (count($result) == 0)
                return $this->rh->success($result);

            return $this->rh->success($this->feedForeignValue($result)[0]);
        }
        return $this->rh->error("Record not Found in $this->tableName for id $id");
    }

    /**
     * Return Record for given id
     * 
     * @param id string
     */
    public function deleteById($id)
    {
        $result = $this->db->delete($this->tableName, "id=$id");
        if ($result) {
            return $this->rh->success($result);
        }
        return $this->rh->error("Record not deleted $this->tableName");
    }

    private function feedForeignValue($result)
    {
        foreach ($result as $key => $value) {
            $result[$key] =  $this->getForeignValues($value);
        }
        return $result;
    }


    /**
     * Return Record for given foreign id
     * 
     * @param id string
     */
    public function getByOtherForeignId($condition)
    {
        $result = $this->db->getAll($this->tableName, $condition);
        if (is_array($result)) {
            return $this->rh->success($this->feedForeignValue($result));
        }
        return $this->rh->error("Record not Found in $this->tableName for $condition");
    }

    /**
     * Table data 
     */

    protected function tableData()
    {
        $this->columnNames = array_map(function ($columnDefinition) {
            return explode(' ', $columnDefinition)[0];
        }, $this->columns);
        return implode(', ', $this->columns);
    }
}