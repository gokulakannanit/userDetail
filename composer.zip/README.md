# Getting Started on App Engine for PHP 7.2

This sample demonstrates how to deploy a PHP application which integrates with
Cloud SQL and Cloud Storage on App Engine Standard for PHP 7.2. The tutorial
uses the Slim framework.

## View the [full tutorial](https://cloud.google.com/appengine/docs/standard/php7/building-app/)

STEP1: INSTALL xampp AND composer
STEP2: Open XAMPP Control Panel to start Apache and MySql server
STEP5: Create DB name 'meat' in http://localhost/phpmyadmin
STEP3: RUN command line 'composer install' - inside project folder
STEP4: composer start - inside project folder, open POSTMAN and hit http://localhost/employee/get/all
